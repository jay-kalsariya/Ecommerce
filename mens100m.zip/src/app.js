const express = require("express");
require("../src/db/conn");

const MenRanking = require("../src/modeljs/mens");
const router = require("./routers/men");

const app =express();
const port =process.env.PORT ||3000;


app.use(express.json());
app.use(router);

var bodyparser = require('body-parser');
app.use(express.json());
app.use(express.urlencoded({extended:false}));

var ejs = require("ejs");
var path = require("path");
var ejs_folder_path = path.join(__dirname, "../templates");
app.set("view engine", "ejs");
app.set("views", ejs_folder_path);


app.get("/",async  (req,res) =>{
    console.log(path.join(__dirname, "../templates"))

})

app.get("/mens",async(req,res)=>{
    res.render('jay');
})
//we will handle post req
app.post("/mens",async(req,res)=>{
 console.log(req.body)
  res.send(req.body)
 try{
  const addingmensRecords = new MenRanking(req.body)
    console.log(req.body);
    const insertMens = await  addingmensRecords.save();
    res.status(201).send(insertMens);
      

 }  catch(e){
     res.status(400).send(insertMens);


 }

 })

app.post("/post",async(req,res)=>{
    res.send(req.body)
})


app.listen(port,()=>{
    console.log(`connection is live at port no.${port}`);


})