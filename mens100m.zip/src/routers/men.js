 const express = require("express");
 const router = new express.Router();   
 const MenRanking = require("../modeljs/mens");

    
    //we will handle post req 
app.router("/mens",async(req,res)=>{
    try{
     const addingmensRecords =  new MensRanking(req.body);
     console.log(req.body);
     const insertMens = await addingmensRecords.save();
     res.status(201).send (insertMens);

    
     }  catch(e){
        res.status(400).send(e);


    }

})


//we will handle delete req of indiv
router.delete("/mens/:id",async(req,res)=>{
    try{
     const_id =req.params.id;
    const getMen = await  MenRanking.findByIdAndDelete(_id,req.body );
       res.send(getMen);
      

     }  catch(e){
        res.status(500).send(e);


    }


})

module.exports = router;