const mongoose = require("mongoose");
const bcrypt = require("bcryptjs");
const jwt = require("jsonwebtoken");

const employeeSchema = new mongoose.Schema({
    firstname:{
        type:String,
        require:true
    },
    lastname:{
        type:String,
        require:true
    },
    email:{
        type:String,
        require:true,
        uniqe:true
    },
    gender:{
        type:String,
        require:true
    },
    phone:{
        type:Number,
        require:true,
        uniqe:true
    },
    age:{
        type:Number,
        require:true,
        
    },
    password:{
        type:String,
        require:true
    },
    confirmpassword:{
        type:String,
        require:true
    }

})
//generating  tokens
employeeSchema.methods.generateAuthToken =async function(){
    try{
        console.log(this._id);
        const token =jwt.sign({_id:this._id.toString()},process.env.SECRET_KEY);
            this.tokens = this.token.concat({token:token})
            awaitthis.save();
            return token;
    }catch(error){
        res.send("the error part" + error);
        console.log("the error part" + error);
    }
}

//converting password  into hash
employeeSchema.pre("save",async function(next){
    if (this.isModified("password")){
        this.password =await bcrypt.hash(this.password,10);
        this.confirmpassword =await bcrypt.hash(this.password,10);
    }
    next();
})


//now we need to create a Collections

const  Register = new mongoose.model("Register",employeeSchema);

module.exports = Register;