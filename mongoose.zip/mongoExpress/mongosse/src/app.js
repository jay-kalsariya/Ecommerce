const mongooose = require("mongoose");


mongooose.connect("mongodb://localhost:27017/jay",
 {
    useNewUrlparser:true
});

