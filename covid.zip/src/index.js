import React from "react";
import  ReactDOM from "react-dom";


const flname ='jay';

ReactDOM.render(
  <>
  <h1> i am mr jay{flname}</h1>,
  <p> hello my every one are the App{Math.random()}</p>
  </>,
  document.getElementById('root')

);