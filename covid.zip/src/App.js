import React from 'react'
import Covid from './components/covid'

const App = () => {
  return (
    <>
  <Covid/>
    </>
  )
}

export default App
