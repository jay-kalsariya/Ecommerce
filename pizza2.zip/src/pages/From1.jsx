// import React from 'react'
// import { useState } from 'react';
// import '../App.css';
// // import "../styles/Form1.css";


// const Form1 = () => {

// // --------------------Const----------------


//     const [ fname,setfname]=useState("");
//     const [ Lname,setlname]=useState("");
//     const [ Email,setEmail]=useState("");
//     const [ Phone,setphone]=useState("");
//     const [ Password,setpassword]=useState("");
//     const [ cPassword,setcpassword]=useState("");



//     const firstname=(e)=>{
//         setfname(e.target.value)
//     }

//     const Lastname=(e)=>{
//         setlname(e.target.value)
//     }
//     const email=(e)=>{
//         setEmail(e.target.value)
//     }
//     const phone=(e)=>{
//       setphone(e.target.value)
//   }
//   const password=(e)=>{
//     setpassword(e.target.value)
// }
// const cpassword=(e)=>{
//   setcpassword(e.target.value)
// }

 
//     const handleSubmit=(e)=>{
//         e.preventDefault();
//         setfname("");
//         setlname("");
//         setEmail("");
//         setphone("");
//         setpassword("");
//         setcpassword("")

//     }

    

  
    
//   return (

//     <div>
//       <div className="container">
//        <form className="row g-3" onSubmit={handleSubmit}>
//        <h2 className="title">SIGN UP FORM</h2>
//         <div className="col-md-4">
         
//              {/* ----------------------FirstName-------------- */}
//           <label htmlFor="validationServer01" className="form-label">
         
//             First Name:
//           </label>
//           <input
//             type="text"
//             className="form-control"
//             id="firstname"
//             onChange={firstname}
//             value={fname}
//           />
//         </div>

        
//           {/* -----------------LastNaME--------------- */}
//         <div className="text">
          
//           <label htmlFor="validationServer02" className="form-label">
          
//             Last Name:
//           </label>
//           <input
//             type="text"
//             className="form-control"
//             id="lastname"
//              onChange={Lastname}
//             value={Lname}
//             style={{
//               width: "360px",
             
//             }}
           
//           />
//         </div>
//         <div className="form-check form-check-inline">
//           <label htmlFor="validationServer01" className="form-label">
//             Gender :
//           </label>
//           <div className="form-check form-check-inline">
//             <input
//               className="form-check-input"
//               type="radio"
//               name="inlineRadioOptions"
//               id="inlineRadio1"
//               value="option1"
//             />
//             <label className="form-check-label" htmlFor="inlineRadio1">
//               Male
//             </label>
//           </div>
//           <div className="form-check form-check-inline">
//             <input
//               className="form-check-input"
//               type="radio"
//               name="inlineRadioOptions"
//               id="inlineRadio2"
//               value="option2"
//             />
//             <label className="form-check-label" htmlFor="inlineRadio2">
//               Female
//             </label>
//           </div>
//           <div className="form-check form-check-inline">
//             <input
//               className="form-check-input"
//               type="radio"
//               name="inlineRadioOptions"
//               id="inlineRadio3"
//               value="option3"
//             />
//             <label className="form-check-label" htmlFor="inlineRadio2">
//               Other
//             </label>
//           </div>
//         </div>

//         <div className="col-md-4">
//           <label htmlFor="validationServer03" className="form-label">
//             Email Address :
//             {/* ------------------eMAIL------------------ */}
//           </label>
//           <input
//             type="text"
//             className="form-control "
//             id="Email"
//             onChange={email}
//             value={Email}
            
//           />
//         </div>

//         <div className="row-mx-4">
//           <label htmlFor="validationServer04" className="form-label">
//             Phone Number :
//           </label>
//           <br />
//           {/* ---------------------Phone Num--------------- */}
//           <input
//             type="text"
//             className="form-control1"
//             id="Phone"
//             onChange={phone}
//             value={Phone}
//             style={{
//               width: "360px",
//               height: "40px",
//               borderRadius: "5px",
//               border: "2px solid",
//               color: "white",
//               backgroundcolor: "cadetblue",
//             }}
            
//           />
//         </div>
//         <div className="col-md-3">
//           <label htmlFor="validationServer05" className="form-label">
//             Password :
//           </label>
//                     {/* ---------------------Password--------------- */}

//           <input
//             type="text"
//             className="form-control"
//             id="password"
//             onChange={password}
//             value={Password}
//             style={{
//               width:"361px",
//             }}
           
//           />
//         </div>
// {/* ---------------------ConFirm Password--------------- */}

//         <div className="row-md-4">
//           <label htmlFor="validationServer05" className="form-label">
//             {" "}
//             ConFirm Password :
//           </label>

 
//           <input
//             type="text"
//             className="form-control is"
//             id="confirm password"
//             onChange={cpassword}
//             value={cPassword}
//             style={{
//               width:"361px",
//             }}
           
//           />
//         </div>
//         <div className="col-12"></div>

//         <div className="col-4">
//           <button className="btn btn-danger" type="submit">
//             CREATE YOUR PROFILE
//           </button>
//         </div>
//       </form>
//     </div>
//     </div>
//   )
// }

// export default Form1;
