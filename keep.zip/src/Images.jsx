import React from "react";


const Images =(props) => {
    return  <img src={props.imgsrc} alt="mypic" className="card_img"/>;
}

export default Images;