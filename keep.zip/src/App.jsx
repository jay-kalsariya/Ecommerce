import React from "react";
import "../node_modules/bootstrap/dist/css/bootstrap.min.css";

//  import React, { useState } from "react";

// import Amazon from "./Amazon";
// import Card from "./Cards";
// import Netfix from "./Netflix";
// import Sdata from "./Sdata";

const App = () => {
  return (
    <React.Fragment>
      <h1 className="text-center text-danger text-capitalize my-5">
        {" "}
          welcome to hello{""}</h1>
      <div classNameName="container" >
        <div classNameName="row">
          <div classNameName="col-sm">
            <div className="card" style="width: 18rem;">
              <img
                src="https://picsum.photos/200/300"
                className="card-img-top"
                alt="..."
              />
              <div className="card-body">
                <h5 className="card-title">Card title</h5>
                <p className="card-text">
                  Some quick example text to build on the card title and make up
                  the bulk of the card's content.
                </p>
                <a href="#" className="btn btn-primary">
                  Go somewhere
                </a>
              </div>
            </div>
            Column
          </div>
          <div className="col-sm">
            <div className="card" style="width: 18rem;">
              <img
                src="https://picsum.photos/201/300"
                className="card-img-top"
                alt="..."
              />
              <div className="card-body">
                <h5 className="card-title">Card title</h5>
                <p className="card-text">
                  Some quick example text to build on the card title and make up
                  the bulk of the card's content.
                </p>
                <a href="#" className="btn btn-primary">
                  Go somewhere
                </a>
              </div>
            </div>
            Column
          </div>
          <div className="col-sm">
            {" "}
            <div className="card" style="width: 18rem;">
              <img
                src="https://picsum.photos/202/300"
                className="card-img-top"
                alt="..."
              />
              <div className="card-body">
                <h5 className="card-title">Card title</h5>
                <p className="card-text">
                  Some quick example text to build on the card title and make up
                  the bulk of the card's content.
                </p>
                <a href="#" className="btn btn-primary">
                  Go somewhere
                </a>
              </div>
            </div>
            Column
          </div>
        </div>
      </div>
    </React.Fragment>
  );
};

export default App;

// const App = () => {
//     let newtime = new Date().toLocaleTimeString();

//     const [ctime, setCtime] = useState(newtime);
//     const UpdateTime = () =>{
//         newtime = new Date().toLocaleTimeString();
//        setCtime(newtime);
//     }
//     return(
//         <>

//         <h1> {ctime} </h1>
//         <button onClick={UpdateTime}>
//             Get Time
//         </button>
//         </>

//     );
// }
// export default App;

// const App = () =>{
//     const state = useState();
//     // console.log(state);
//     const [count,setcount] = useState(7);

// const IncNum = () =>{
//    setcount(count + 28);
//    //console.log('clicked'+ count++);
// };
// return(
//     <>
//     <h1> {count} </h1>
//     <button onClick={IncNum}> Click Me</button>
//     </>
// );
// };

// export default App;

// const favSeries = 'Netflix ';

// // const FavS = () =>{

// // if(favSeries ==='netflix'){
// //    return <Netfix/>;

// // }else{

// //     return<Amazon/>;
// //     }
// // };

// const App = () =>(
// <>

// <h1 classNameName="heading_style">List of top 10 Nexfix web series in 2022</h1>
// {/* <FavS/> */}
// {(favSeries ==='netflix')?  <Netfix/> : <Amazon/> }
// </>

// );
// export default App;
