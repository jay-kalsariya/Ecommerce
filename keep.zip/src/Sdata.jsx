const Sdata =[
    {
        id:1,
        sname:"DARK",
        imgsrc:"https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTmiHTDXkHnolrRvd3O8E9wpLqT6iHvu7G88w&usqp=CAU",
        title:"Netfix original Series",
        links:"https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTmiHTDXkHnolrRvd3O8E9wpLqT6iHvu7G88w&usqp=CAU",
    },
    {
        id:2,
          sname:"extra curricular",
          imgsrc:"https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTSgGT_O-cAw_FDi6VOHmD7SMO9uNNqAKkm8w&usqp=CAU",
          title:"A Netfix series",
          links :"https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTSgGT_O-cAw_FDi6VOHmD7SMO9uNNqAKkm8w&usqp=CAU",
    },
    {     id:3,
        sname:"Stranger Things",
        imgsrc:"https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcS_qxI3GgRZ5QMHtBDd3Kzu3vWrtGuy_rlLLg&usqp=CAU",
         title:"A Netfix series",
         links:"https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcS_qxI3GgRZ5QMHtBDd3Kzu3vWrtGuy_rlLLg&usqp=CAU"

    },

    {    id:4, 
        sname:"Big Bull",
        imgsrc:"https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQehpSRxn2x2GOXgna_HSkrw2TkVTf5pUGFuw&usqp=CAU",
         title:"A Netfix series",
         links:"https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQehpSRxn2x2GOXgna_HSkrw2TkVTf5pUGFuw&usqp=CAU"

    },

    {    id:5, 
        sname:"RRR",
        imgsrc:"https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQ1tnV3xMgNuFonZ5skM7A7Z-2ciapGRML2lw&usqp=CAU",
         title:"A Netfix series",
         links:"https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTSgGT_O-cAw_FDi6VOHmD7SMO9uNNqAKkm8w&usqp=CAU"

    },


    {
        id:6,
        sname:"extra curricular",
        imgsrc:"https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTSgGT_O-cAw_FDi6VOHmD7SMO9uNNqAKkm8w&usqp=CAU",
        title:"A Netfix series",
        links :"https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTSgGT_O-cAw_FDi6VOHmD7SMO9uNNqAKkm8w&usqp=CAU",
  },


  {   id:7,  
    sname:"RRR",
    imgsrc:"https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQ1tnV3xMgNuFonZ5skM7A7Z-2ciapGRML2lw&usqp=CAU",
     title:"A Netfix series",
     links:"https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTSgGT_O-cAw_FDi6VOHmD7SMO9uNNqAKkm8w&usqp=CAU"

},


];
export default Sdata;
