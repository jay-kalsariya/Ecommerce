import React from "react";
import ReactDOM from "react-dom";
import App from "./App";
// import Event from "./Events";    
import Todolist from "./Todolist";
 
 ReactDOM.render(<App/>,document.getElementById("root"));



//  const fullname = ['jay','kalsariya'];

//  const biodata =[1,...fullname,28,'male'];
//  console.log(fullname);
// console.log(biodata);

