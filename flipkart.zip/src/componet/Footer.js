import React from 'react'
import '../main_css/Footer.css'
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome'
import { faFacebookF, faInstagram, faTwitter } from '@fortawesome/free-brands-svg-icons' 
import { faAt } from '@fortawesome/free-solid-svg-icons'

export default function Footer() {
  return (
    <div className='footer'>
     
 <FontAwesomeIcon className='icon1' icon={faAt} />
 <FontAwesomeIcon className='icon2' icon={faFacebookF} />
 <FontAwesomeIcon className='icon' icon={faInstagram} />
 <FontAwesomeIcon className='icon3' icon={faTwitter} />
<br />
 <div className="copy">
&copy; 2007-2022 Flipkart.com
</div>
    </div>
  )
}
