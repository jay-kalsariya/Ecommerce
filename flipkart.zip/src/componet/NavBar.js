import React from "react";
import card from "../images/cart.png";
import { Link } from "react-router-dom";
import '../main_css/NavBar.css';
import flip from "../images/flipkart.png"
import plus from "../images/plus.png"
import profile from "../images/Login/profile.jpg"
import add from "../images/Login/plus.webp"
import orders from "../images/Login/orders.jpg"
import wishlist from "../images/Login/wishlist.jpeg"
import rewards from "../images/Login/rewards.webp"
import gift from "../images/Login/gift.webp"
import notic from "../images/more/notification.jpg"
import customer from "../images/more/customer.jpeg"
import advertise from "../images/more/advertise.png"
import download from "../images/more/download.png"
export default function NavBar() {
  return (
    <div>
      <nav className="navbar navbar-expand ">
        <div className="container ">
          <Link
          
            to="/"
            
          >
            <img src={flip} alt="" className="imgflip" />
        
          </Link  >
  
              <Link  className="explore" to="/plus">
                Explore
                <span className="plus"> plus</span>
                <img src={plus} alt="" style={{width:'10px',
                                                    position: 'relative',
                                                    top: '-18px',
                                                    left: '62px'}}/>
           </Link>
        
          <div className="collapse navbar-collapse mx-4" id="">
            <form className="d-flex">
              <input
                className="input"
                type="text"
                placeholder="Search for products,brand and more"
            
              />
          <Link to="/"> <h5> <i className="fa fa-search"></i></h5></Link>

              <div className="dropdown1">
                <Link to="login">
                <button
                  className="login"
                  id="drop"
                  aria-expanded="false"
                  type="submit"
                >
                  Login
                </button>
                </Link>
                
                <div className="new" >
                  <div to="/Signup" className="dropdown-item1">
                    New Customers? 
                    <Link
                      to="/Signup"
                      className="sign"
                    >
                      Sign up
                    </Link>
                 </div>
                 <Link to="/" className="dropdown-item1">
                  <hr className="su"/>
                  <Link to="/My Profile" className="dropdown-item1">
                   <img src={profile} alt="" style={{width:'20px',margin:'0px 20px 0px 0px'}}/> My Profile
                  </Link>
                  <hr className="su" />
                  <Link to="/Flipkart Plus Zone" className="dropdown-item1">
                  <img src={add} alt="" style={{width:'22px',margin:'0px 20px 0px 0px'}}/> Flipkart Plus Zone
                  </Link>
                  <hr className="su"/>        
                  <Link to="/Flipkart Plus Zone" className="dropdown-item1">
                  <img src={orders} alt="" style={{width:'25px',margin:'0px 20px 0px 0px'}}/> Orders
                  </Link>
                 
                  <hr className="su" />
                  <Link to="/Flipkart Plus Zone" className="dropdown-item1">
                  <img src={wishlist} alt="" style={{width:'20px',margin:'0px 20px 0px 0px'}}/> Wishlist
                  </Link>
                
                  <hr className="su" />
                  <Link to="/Flipkart Plus Zone" className="dropdown-item1">
                  <img src={rewards} alt="" style={{width:'20px',margin:'0px 20px 0px 0px'}}/> Rewards
                  </Link>
                 
                  <hr className="su" />
                  <Link to="/Flipkart Plus Zone" className="dropdown-item1">
                  <img src={gift} alt="" style={{width:'20px',margin:'0px 20px 0px 0px'}}/>Gift cards
                  </Link>
                </Link>
                </div>
               
              </div>
            </form>
            <Link
              className="navbar-brand text-light"
              style={{ margin: "0px 37px" }}
              to="/Become a Seller"
            >
              Become a Seller
            </Link>

            <ul className="navbar-nav me-auto mb-2 mb-lg-0">
              <li className="nav-item ">
                <Link
                  className="nav-link dropdown-toggle text-light"
                  to="/MORE"
                  id="navbarDropdown"
                >
                  More
                </Link> 
                <Link to="/">                 
                <ul className="more">
                  <li>
                    <Link
                      className="drop"
                      to="/Notification performance"
                    >
                     <img src={notic} alt="" style={{ width: '25px',margin: '4px 12px 8px -5px'}}/>
                      Notification performance
                    </Link>
                  </li>
                  <li>
                    <hr className="dropdown-divider" />
                  </li>
                  <li>
                    <Link className="drop" to="/24x7 Customer Care">
                    <img src={customer} alt="" style={{ width: '25px',margin: '4px 12px 8px -5px'}}/>
                      24x7 Customer Care
                    </Link>
                  </li>
                  <li>
                    <hr className="dropdown-divider" />
                  </li>
                  <li>
                    <Link className="drop" to="/Advertise">
                    <img src={advertise} alt="" style={{ width: '25px',margin: '4px 12px 8px -5px'}}/>
                      Advertise
                    </Link>
                  </li>
                  <li>
                    <hr className="dropdown-divider" />
                  </li>
                  <li>
                    <Link className="drop" to="/Download App">
                    <img src={download} alt="" style={{ width: '20px',margin: '4px 17px 4px 0px'}}/>
                   
                      Download App
                    </Link>
                  </li>
                </ul>
                 </Link> 
              </li>
            </ul>
           

            <Link
              className="navbar-brand text-light"
              style={{ margin: "0px 50px" }}
              to="/cart"
            >
              <img src={card} alt="" style={{ width: "30px" }} /> Cart
            </Link>
          </div>
        </div>
      </nav>
    </div>
  );
}
