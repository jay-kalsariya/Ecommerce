import NavBar from './componet/NavBar';
import Signup from './login/Signup'
import Login from './login/Login';
import {
  Routes,
  Route,
} from "react-router-dom";
import Footer from './componet/Footer';
import TextForm from './pages/TextForm';
import Offer from './pages/Offer';


function App() {
  

  return (
    <div>
    <NavBar/>
    <Routes>
      <Route exact path="Signup" element={<Signup/>} />
      <Route exact path="login" element={<Login/>} />
      <Route exact path="/"  element={ <TextForm/>} />
      <Route exact path="Mobile" element={<Offer /> } />
 
    </Routes>
 
     <Footer/>
   
    </div>
  );
}

export default App;

