import React, { useState } from 'react'
import '../main_css/DateTime.css'

export default function DateTime() {
  let time = new Date().toLocaleString();
  const [ctime,setCtime] = useState(time)

  const updatatime = () =>{
    time = new Date().toLocaleString();
    setCtime(time)
  };
  setInterval(updatatime, 1000);
  return (
    <div>
      <div className="box1">
  <h2> Deals of Day</h2> <h4> 🕐 { ctime} Left</h4>
   <button className='view'>VIEW ALL</button>

</div>
    </div>
  )
}
