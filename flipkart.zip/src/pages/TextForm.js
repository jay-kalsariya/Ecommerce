import React from 'react'
import mobile from '../images/mobile.webp'
import fashion from '../images/fashion.webp'
import electonic from '../images/electronic.webp'
import beauty from '../images/beauty.webp'
import home from '../images/home.webp'
import Large from '../images/large.webp'
import Furniture from '../images/Furniture.webp'
import travel from "../images/travel.webp"
import img9 from '../images/img9.webp'
import img10 from '../images/img10.webp'
import img11 from '../images/side.webp'
import Grocery from '../images/Grocery.webp'
import DateTime from '../pages/DateTime'
import Product from './Product';
import { Link } from 'react-router-dom'
import {useEffect,useState} from 'react'
import '../main_css/TextForm.css'
export default function TextForm() {
  const [users,setUser]=useState([])
  useEffect(()=>{
    fetch("api").then((result)=>{
      result.json().then((resp)=>{
        // console.warn(resp)
        setUser(resp)
      })
    })
  },[])
  console.warn(users)
  return (
      <> 
    <div className="box">
    <div className='container1' >
        <Link  className='navbar-brand' to="/Mobile">
     <img src={mobile} alt="" className='img1' /> 
   
      <h6 >Mobiles</h6> 
    </Link>
 
      <Link to="/Fashion" className='navbar-brand '>
     <img src={fashion} alt="" className="img1"/>
      
        <h6> Fashion</h6>
          </Link>

    <Link to="/Electronic" className='navbar-brand '>
     <img src={electonic} alt="" className='img1'/>
     
          <h6>Electronic</h6>
          </Link>

       <Link to="/Beauty" className='navbar-brand'>
       <img src={beauty} alt="" className='img1'/>
      
          <h6>Beauty</h6>
        </Link>

       <Link to="/Home" className='navbar-brand'>
        <img src={home} alt="" className='img1'/>
     
          <h6 >Home</h6>
      </Link>
    <Link to="/Large" className='navbar-brand '>
      <img src={Large} alt="" className='img1'/>
     
          <h6>Large</h6>
      </Link>
      <Link   to="/Furniture" className='navbar-brand '>
     <img src={Furniture} alt="" className='img1' />
    
          <h6>Furniture</h6>
      </Link>
      <Link   to="/Travel" className='navbar-brand'>
     <img src={travel} alt="" className='img1' />
   
          <h6>Travel</h6>
      </Link>

    <Link   to="/Grocery" className='navbar-brand'>
     <img src={Grocery} alt="" className='img1' />
       
          <h6>Grocery</h6>
      </Link>
      </div>
    </div>
   
    <hr />
    <Link to="/" >
    <div id="carouselExampleControls" className="carousel slide" data-bs-ride="carousel">
  <div className="carousel-inner">
    <div className="carousel-item active">
      <img src={img9} alt="" className="d-block w-100 " />
    </div>
    <div className="carousel-item">
      <img src={img10} alt="" className="d-block w-100" />
    </div>
    <div className="carousel-item">
      <img src={img11} alt="" className="d-block w-100" />
    </div>
  </div>
  <button className="carousel-control-prev" type="button" data-bs-target="#carouselExampleControls" data-bs-slide="prev">
    <span className="carousel-control-prev-icon" aria-hidden="true"></span>
    <span className="visually-hidden">Previous</span>
  </button>
  <button className="carousel-control-next" type="button" data-bs-target="#carouselExampleControls" data-bs-slide="next">
    <span className="carousel-control-next-icon" aria-hidden="true"></span>
    <span className="visually-hidden">Next</span>
  </button>
</div> 
</Link>
   <hr />
     

       <DateTime/>

       <Product/>
       {/* <div>
       <h1>Get API Call </h1>
      <table border="1">
       <tbody>
       <tr>
          <td>ID</td>
          <td>Name</td>
          <td>Email</td>
          <td>Mobile</td>
        </tr>
        {
          users.map((item,i)=>
            <tr key={i}>
            <td>{item.userId}</td>
          <td>{item.name}</td>
          <td>{item.email}</td>
            <td>{item.mobile}</td>
          </tr>
          )
        }
       </tbody>
      </table>
      </div> */}
   </>
  )
}
