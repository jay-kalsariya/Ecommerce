import React from 'react'
import "../main_css/product.css"
import prod from "../images/products/phone.webp"
import prod1 from "../images/products/camera.webp"
import prod2 from "../images/products/headphones.jpeg"
import prod3 from "../images/products/laptop.webp"
import prod4 from "../images/products/shoes.webp"
import prod5 from "../images/products/watch.webp"
import prod6 from "../images/products/toy.jpeg"


export default function product() {
  return (
    <div className="box3">
        <div className='box2'>
        <img src={prod} alt="" className='prod'/>
           <br />
           Vivo 
            <br />
             Rs.25000
             
      </div>
      <div className='box2'>
        <img src={prod1} alt="" className='prod'/>
           <br />
          camera
            <br />
             Rs.30000
             
      </div>
      <div className='box2'>
        <img src={prod2} alt="" className='prod'/>
           <br />
           Headphone 
            <br />
             Rs.15000
             
      </div>
      <div className='box2'>
        <img src={prod3} alt="" className='prod'/>
           <br />
           Leptop
            <br />
             Rs.45000
             
      </div>
      <div className='box2'>
        <img src={prod4} alt="" className='prod'/>
           <br />
        Shoes
            <br />
             Rs.900
             
      </div>
      <div className='box2'>
        <img src={prod5} alt="" className='prod'/>
           <br />
          Watch
            <br />
             Rs.35000
             
      </div>
      <div className='box2'>
        <img src={prod6} alt="" className='prod'/>
           <br />
          Toy
            <br />
             Rs.8500
             
      </div>
      
    </div>
  )
}
