import React, { useState } from 'react'
import "../main_css/Offer.css"
import { Link } from 'react-router-dom'
import Api from "../Api/Api"
const Offer = () => {
  const [items,setItems] = useState(Api)
  return (
<>
<div className="mobile">
<h1>All Mobiles</h1>
      {items.map((elem)=>{
        const {id,image,name,price}=elem;
        return (
          <div className="outer" key={id}>
          <div className="inner">
              <img src={image} alt="" className='mob' />
              <div className="info">
              <span className='category'>{name}</span>
              <h6>{price}</h6>
            <Link to="/buy now">
              <button className='btn btn-primary'>buy now</button>
              </Link>
              </div>
          </div>
      </div>
 
        );
      })}
 

 </div>
</>
  )
}

export default Offer
