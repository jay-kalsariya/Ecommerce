import React from "react";
import { useState } from "react";
import '../main_css/Signup.css'
export default function Signup() {

   const [formValues, setFormValues] = useState({
          isAgree :false,
          gender :""
  });
  const [formErrors, setFormErrors] = useState({});
  const [isSubmit, setIsSubmit] = useState(false);
 
  const handleChange = (e) => {
   const target = e.target
   const name  = target.name
   const value = target.value
    setFormValues({ ...formValues, [name]: value });

  };
  const handleSubmit = (e) => {
    e.preventDefault();
    setFormErrors(validate(formValues));
    setIsSubmit(true);
  }
  const validate = (values) => {
    const errors = {};
    const regex = /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/i;
    if (!values.firstname) {
      errors.firstname = "First Name is required!";
    }
    if (!values.Surname) {
      errors.Surname = "Surname is required!";
    }
    if (!values.email) {
      errors.email = "Email is required!";
    } else if (!regex.test(values.email)) {
      errors.email = "This is not a valid email format!";
    }
    if (!values.password) {
      errors.password = "Password is required";
    } else if (values.password.length < 4) {
      errors.password = "Password must be more than 4 characters";
    } else if (values.password.length > 10) {
      errors.password = "Password cannot exceed more than 10 characters";
    }
    return errors;
  };

 
  return (
    <>
      <div className="from my-3">
        <form className="row g-0" name="forms" onSubmit={handleSubmit}>
          <div className="row g-2">
            <h1>Sign Up</h1>
            <h6>It's quick and easy.</h6>
            <hr />
            <div className="col">
              <input
                type="text"
                name="firstname"
                id="firstname"
                className="form-control"
                placeholder="First name"
                value={formValues.firstname}
                onChange={handleChange}
                autoComplete="off"
              />
              <p>{formErrors.firstname}</p>
            </div>

            <div className="col">
              <input
                type="text"
                className="form-control"
                placeholder="Surname"
                name="Surname"
                value={formValues.Surname}
                onChange={handleChange}
                autoComplete="off"
              />
              <p>{formErrors.Surname}</p>
            </div>
            <div className="row-10 my-3">
              <input
                type="text"
                className="form-control"
                name="email"
                value={formValues.email}
                onChange={handleChange}
                placeholder="Email Address"
                autoComplete="off"
         
              />
              <p>{formErrors.email}</p>
            </div>
            <div className="row-10 my-2">
              <input
                type="text"
                className="form-control"
                placeholder="New Password"
                name="password"
                value={formValues.password}
                onChange={handleChange}
                autoComplete="off"
                
              />
              <p>{formErrors.password}</p>
            </div>

            <div className="form-check form-check-inline">
              <label
                className="form-check-label mx-2 "
                htmlFor="inlineCheckbox1"
              >
                Gander:
              </label>

              <div className="form-check form-check-inline">
                <input
                  className="form-check-input"
                  type="radio"
                  name="gender"
                  id="inlineRadio1"
                  value="male"
                  onChange={handleChange}
                />
                <label className="form-check-label" htmlFor="inlineRadio1">
                  Male
                </label>
              </div>
              <div className="form-check form-check-inline">
                <input
                  className="form-check-input"
                  type="radio"
                  name="gender"
                  id="inlineRadio2"
                  value="female"
                  onChange={handleChange}
                />
                <label className="form-check-label" htmlFor="inlineRadio2">
                  Female
                </label>
              </div>
              <div className="form-check form-check-inline">
                <input
                  className="form-check-input"
                  type="radio"
                  name="gender"
                  id="inlineRadio3"
                  value="other"
                  onChange={handleChange}
                />
                <label className="form-check-label" htmlFor="inlineRadio2">
                  Other
                </label>
              </div>
            </div>
          </div>
          <div className="col-12">
            <button
              type="submit"
              className="btn2 btn-success mx-2 my-4"
            >
              Sign Up
            </button>
          </div>
        </form>
      </div>
       {/* <div className="display">
         <h5>First Name :{formValues.firstname}</h5>
         <h5>User Name :{formValues.Surname}</h5>
         <h5>Email Id :{formValues.email}</h5>
         <h5>Password :{formValues.password}</h5>
         <h5>Gender : {formValues.gender}</h5>


       </div> */}

    </>
  );
}
