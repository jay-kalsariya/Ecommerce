import React from "react";
import { useState } from "react";
import '../main_css/Login.css'

export default function Login() {
  const initialValues = {};
  const [formValues, setFormValues] = useState(initialValues);
  const [formErrors, setFormErrors] = useState({});
  const [isSubmit, setIsSubmit] = useState(false);

  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");

  const [allEntry, setAllEntry] = useState([]);

  const handleChange = (e) => {
  const { name, value } = e.target;
  setFormValues({ ...formValues, [name]: value });

  };

  const handleSubmit = (e) => {
    e.preventDefault();
    setFormErrors(validate(formValues));
    setIsSubmit(true);
    
    const newEntery = { username: username, password: password };
    setAllEntry([...allEntry, newEntery]);
    setUsername(" ");
    setPassword(" ");
  };

  const validate = (values) => {
    const errors = {};

    if (!values.username) {
      errors.username = "UserName is required!";
    }
    if (!values.password) {
      errors.password = "Password is required";
    } else if (values.password.length < 4) {
      errors.password = "Password must be more than 4 characters";
    } else if (values.password.length > 10) {
      errors.password = "Password cannot exceed more than 10 characters";
    }
    return errors;
  };

  return (
    <>
      <div className="from1 my-4">
        <form action="" className="col1" onSubmit={handleSubmit}>
          <div className="col1-md-3">
            <input
              type="text"
              name="username"
              id="username"
              className="lg my-3"
              placeholder="UserName"
              value={formValues.username}
              onChange={handleChange }
            />
          </div>
          <p>{formErrors.username}</p>
          <div className="col1-md-3">
            <input
              type="text"
              name="password"
              id="password"
              className="lg my-3"
              placeholder="Password"
              value={formValues.password}
              onChange={handleChange }
            />
          </div>
          <p>{formErrors.password}</p>
          <div className="col1-12">
            <button
              type="submit"
              className="btn1"
              //  onClick={submit}
            >
              Log In
            </button>
          </div>
        </form>
      </div>
   
      {/* <div className="data">
        <tr>
          <td style={{ position: "relative", left: "-40px" }}>UserName</td>
          <td style={{ position: "relative", left: "5px" }}>Password</td>
        </tr>
        
        {allEntry.map((curElem) => {
          return (
            <div className="indata">
              <tr>
                <td >
                  {curElem.username}
                </td>
                <td>
                  {curElem.password}
                </td>
              </tr>
            </div>
          );
        })}
      </div> */}
    
    </>
  );
}

