const Sdata = [
  {
    id: 1,
    image:"https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcS-CuzSaKSd2Robo_mkFlWsW59tMDi8K-QL7Q&usqp=CAU",
    name: "Iphone",
    price:"Rs.80000"
  },
  {
    id: 2,
    image:"https://opsg-img-cdn-gl.heytapimg.com/epb/202205/26/v7cbud6vUmPJnxTY.png",
    name: "Oppo",
    price:"Rs.21000"
  },
  {
    id: 3,
    image:"https://static.toiimg.com/thumb/resizemode-4,msid-64799737,imgsize-200,width-1200/64799737.jpg",
    name: "OnePlus",
    price:"Rs.30000"
  },
  {
    id: 4,
    image:"https://www.91-img.com/pictures/138402-v6-vivo-v20-mobile-phone-large-1.jpg?tr=h-241,c-at_max,q-80",
    name: "Vivo",
    price:"Rs.25000"
  },
  {
    id: 5,
    image:"https://assets.mspimages.in/c/tr:w-375,h-300,c-at_max/17042-217-1.jpg",
    name: "Redmi",
    price:"Rs.15000"
  },
  {
    id: 6,
    image:"https://media.extra.com/s/aurora/100309921_800/Nokia-G21%2C-4G%2C-64GB%2C-Blue?locale=en-GB,en-*,*&$Listing-Product-2x$",
    name: "Nokia",
    price:"Rs.12000"
  },
  {
    id: 7,
    image:"https://dealntechcdn.b-cdn.net/wp-content/uploads/2019/06/samsung-note-10-plus.jpg",
    name: "Samsung",
    price:"Rs.17000"
  },
  {
    id: 8,
    image:"https://www.infinixmobility.com/fileadmin/assets/images/product/list/note8i.jpg",
    name: "Infinix",
    price:"Rs.10000"
  },
  {
    id: 9,
    image:"https://www.91-img.com/pictures/138385-v2-realme-7-mobile-phone-large-1.jpg",
    name: "Realme",
    price:"Rs.13000"
  },
  {
    id: 10,
    image:"https://www.gizmochina.com/wp-content/uploads/2019/09/Sony-Xperia-5.jpg",
    name: "Sony Xperia 5",
    price:"Rs.18500"
  },

];
export default Sdata;