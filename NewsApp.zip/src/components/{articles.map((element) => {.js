{articles.map((element) => {
    return <div className="col-md-4" key={element.url}>
        <NewsItem title={element.title ? element.title : ""} description={element.description ? element.description : ""} imageUrl={element.urlToImage} newsUrl={element.url} author={element.author} date={element.publishedAt} source={element.source.name} />
    </div>
})}