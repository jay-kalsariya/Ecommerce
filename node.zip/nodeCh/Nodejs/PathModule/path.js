const path = require("path");


console.log(path.dirname('c058@C058:~ Desktop/Node/nodeCh/fsAsync/Osmodule/PathModule/path.js'));
console.log(path.extname('c058@C058:~ Desktop/Node/nodeCh/fsAsync/Osmodule/PathModule/path.js'));
console.log(path.basename('c058@C058:~ Desktop/Node/nodeCh/fsAsync/Osmodule/PathModule/path.js'));

const mypath = path.parse('c058@C058:~ Desktop/Node/nodeCh/fsAsync/Osmodule/PathModule/path.js');
console.log(mypath.root);

