// const fs = require('fs');

const { fstat } = require("fs");

//  fs.mkdir('jay',(err) =>{

//     console.log("folder created");

//  });


 fs.writeFile("./jay/bio.txt","i am good Afternoon",(err)=>{
    console.log("file created");
});

// fs.appendFile("./jay/bio.txt", "i am fine brother",(err)=>{
//     console.log("files data appends");
// });

// fs.readFile("./jay/bio.txt","utf-8",(err,data)=>{

//     console.log(data);

// });


// fs.rename("./jay/bio.txt","./jay/myBio.txt",(err)=>{

//     console.log("rename done");
    
// });

// fs.unlink("./jay/myBio.txt",()=>{
//     console.log("files deleted");
// });

fs.rmdir('./jay',(err)=>{
    console.log("folder deleted");

})