const fs = require("fs");


// fs.writeFileSync('read.txt',"today is a some day:)",(err) => {
//   console.log("files is created");  
//   console.log(err);
// });

// fs.appendFile("read.txt","i am good Afternoon",
// (err) => {
//     console.log("task completed");
// });

fs.readFile("read.txt","UTF-8",(err,data) => {
    console.log(data);

});