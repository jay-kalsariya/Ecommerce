const bioData ={
    name:"jay",
    age:24,

};
const jsonData =JSON.stringify(bioData);
console.log (jsonData);