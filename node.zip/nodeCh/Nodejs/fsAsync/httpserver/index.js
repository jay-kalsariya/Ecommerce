const fs = require("fs");
const http = require("http");

const server =http.createServer((req,res) =>{
//  console.log(req.url);

 if(req.url ="/"){
    res.end("hello from the others"); 
 }else if(req.url =="/about"){
    res.end("hello from the  About Us others"); 

 }else if(req.url =="/UserApi"){
   fs.readFile(`${__dirname}/UserApi/UserApi.json`,"utf-8",(error,data)=>{
    res.end(data); 
    console.log(data)
   })
   

}else{
   res.writeHead(404,{"contant-type":"text/html"})
   res.end("jay hello ");
}
 
});

 server.listen(8000,"127.0.0.1",()=> {
    console.log("listening to the port no 8000");

});