const EventEmitter = require("events");

const event =newEmitter();



event.on ("saymyname",()=> {
    console.log("your name is jay");
});

event.on ("saymyname",()=> {
    console.log("your name is kalsariya");
});

event.emit("saymyname");