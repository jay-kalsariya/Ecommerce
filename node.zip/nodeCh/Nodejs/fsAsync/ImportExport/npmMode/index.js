// const chalk = require("chalk");
// const chalk=require("chalk");
const chalk = require('chalk');
const validator =  require('validator');
console.log(chalk.red.italic.underline.inverse("false"));

const res = validator.isEmail("jay@gmail.com");
console.log(res ?chalk.green.inverse(res):chalk.red.inverse(res ));