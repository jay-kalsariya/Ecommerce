const a = require('fs');
(function(exports,require,module,_filename,_dirname){
    const name ="jay";
    console.log(name);
    module.exports = {jay}
})
