const add =(a,b)=>{
    return a + b;

};

const name ="jay";


module.exports =name;