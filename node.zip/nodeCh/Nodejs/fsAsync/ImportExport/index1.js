
 const add = require("./oper");
// console.log(add(5,5));
console.log(add);

