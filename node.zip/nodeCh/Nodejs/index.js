 const fs = require ('fs');

 //fs.mkdirSync("jay");

 //fs.writeFileSync("jay/bio.txt","my name is jay hello everyboay");

 
 //fs.appendFileSync("jay/bio.txt","hello hello :)");

//   const data = fs.readFileSync("jay/bio.txt","utf8");
//   console.log(data);

// fs.renameSync("jay/bio.txt","jay/myBio.txt");

// fs.unlinkSync("jay/myBio.txt");

//fs.rmdirSync("jay");