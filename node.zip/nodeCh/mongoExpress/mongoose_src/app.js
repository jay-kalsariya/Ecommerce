const mongooose = require("mongoose");
const validator = require("validator");

//connection creation and creatin a new  db
mongooose.connect("mongodb://localhost:27017/jay", {useNewUrlparser:true,useUnifiedTopology:true})
.then(() => console.log("connection successfull....."))
.catch((err) => console.log(err));

//schema
 // A mongoose schema define the structure of the document,
 // defult value,validations,etc.,

 const playlistSchma= new mongooose.Schema({
    name :{
       type: String,
       required : true,
       unique:true,
       lowerCase:true,
       trim:true,
       minlength:[2,"minimum 2 letters"],
       maxlength:30
    },
    ctype:{
        type:String,
        required:true,
        lowercase:true,
        enum :["fontEnd","backend","database"]
    },
    videos: {
        type:Number,
        // validate(value){
        //   if(value < 0){
        //     throw new Error("videos count should not be negative");
        //   }
        // }
    validate:{
        validator:function(value){
            return value.length < 0
        },
        message:"videos count should not be negative"
    }
    },

    author:String,
    email:{
      type : String,
      required:true,
      uniqe:true,
      validate(value){
        if(!validator.isEmail(value)){
            throw new Error("Email is invalid");
        }
      }
    },
    active:Boolean,
   
    date:{
        type:Date,
        default:Date.now
    }
})  

    
    
 
//  ctype : String,
//  videos : Number,
//  author : String,
//  active :Boolean,

//  date:{
//     type : Date,
//     defult:Date.now
//  }

// })




// connection creation
const playlist = new mongooose.model("playlist",playlistSchma);

// create document  or insert

const createDocument =async () =>{
    try{
        const jsplaylist = new playlist({
            name :"javascript",
            ctype : "Front End",
            videos :150,
            author : "jay",
            active :true,
           
           
        })
        const mongoplaylist = new playlist({
            name :"mongoose.js",
            ctype : "Database",
            videos :10,
            author : "jay",
            active :true,
        })


            const mongooseplaylist = new playlist({
                name :" Mongoosejs",
                ctype : "Database",
                videos :4,
                author : "jay",
                email: "jay@gmail.com", 
                active :true,
           
           
        })

        const expressplaylist = new playlist({
            name :"Express js",
            ctype : "Back End",
            videos :4,
            author : "jay",
            active :true,
       
       
    })

const result = await playlist.insertMany([ mongooseplaylist]);
        console.log(result);
      

    }catch(err){
        console.log(err);
    }
}
//createDocument();


//collection creation
  const Playlist = new mongooose.model("Playlist", playlistSchma);

const getDocument =async () =>{
    try{ const result = await playlist
        // .find({ctype:{$nin : ["Back End","database"]}})
    //     .find( {author:"jay" })
    // .select({name: 1})
    // .sort({name : -1});
    // .countDocuments();
    //.limit(1);
    console.log(result);

}catch(err){
    console.log(err);
}
}
    
//   getDocument();

// update the Document

const updateDocument = async (_id) =>{

    try{
        const result = await playlist.findByIdAndUpdate({_id},{
            $set :{
                name:"Javascript "
            }
           },{
            new :true,
            useFindAndModify : false

           } );
        
           console.log(result);
      

    }catch(err){
        console.log(err);

    }
}
   

// updateDocument("62ea4733f8b38ce658b2ec93");


//DeleteDocument

const deleteDocument = async (_id) =>{
    try{
        const result = await  Playlist.findByIdAndDelete({_id});
        console.log(result);

    }catch(err){
        console.log(err);
    }

    
 


}

deleteDocument("62ea4733f8b38ce658b2ec95")