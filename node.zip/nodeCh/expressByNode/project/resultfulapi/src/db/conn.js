const mongoose = require("mongoose");

mongoose.connect("mongodb://localhost:27017/students-api",{
    // useCreateIndex:true,
    // useNewUrlparser:true,
    // useUnifiedTopology:true,
    // useFindAndModify:false,
})
    .then(() => {
        console.log("conn okay");
    })
    .catch((e) => {
        console.log(e);
    })